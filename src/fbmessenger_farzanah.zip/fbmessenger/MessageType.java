package fbmessenger;

public enum MessageType {
    TEXT(1),IMAGE(2),AUDIO(3),VIDEO(4),STICKER(5),GIF(6);
    MessageType(int value){

    }
}
