package fbmessenger;

public class ContentTypes{
    //common empty class
}

class Image extends MessageContent{
    public void getImage(){

    }
}
class Video extends MessageContent{
    public void getVideo(){

    }
}
class Text extends MessageContent{
    public void getText(){

    }
}
class Audio extends MessageContent{
    public void getAudio(){

    }
}

class Sticker extends MessageContent{
    public void getSticker(){

    }
}

class Gif extends MessageContent{
    public void getGif(){

    }
}

